@echo off
cd /d "%~dp0"
py -3.8 noise_guard.py
if errorlevel 1 python noise_guard.py
pause
