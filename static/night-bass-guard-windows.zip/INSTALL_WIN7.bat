@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto NOPY
py -3.8 -m pip install --upgrade pip
py -3.8 -m pip install -r requirements-noise-guard.txt
if errorlevel 1 goto ERR
echo.
echo Hotovo. Spust START_NOISE_GUARD.bat
pause
exit /b 0
:NOPY
echo Neni nalezen Python Launcher. Nainstaluj Python 3.8.10 pro Windows 7 a zaskrtni Add Python to PATH.
pause
exit /b 1
:ERR
echo Instalace balicku se nepovedla. Zkontroluj internet a Python 3.8.
pause
exit /b 1
