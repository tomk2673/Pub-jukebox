from __future__ import annotations

import argparse
import csv
import json
import math
import os
import queue
import sys
import threading
import time
import webbrowser
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

import numpy as np
import sounddevice as sd
from scipy import signal

APP_NAME = "PUB Jukebox Noise Guard"
BASE = Path(__file__).resolve().parent
CONFIG_PATH = BASE / "noise_guard.json"
LOG_DIR = BASE / "noise_logs"

DEFAULT_CONFIG = {
    "input_device": None,
    "sample_rate": 48000,
    "block_ms": 125,
    "calibration_offset_db": 120.0,
    "warning_laeq_db": 55.0,
    "warning_lceq_db": 65.0,
    "point_seconds": 20,
    "venue_name": "Ztraceny bar",
    "measurement_note": "Interni orientacni provozni kontrola. Nejde o autorizovane mereni hluku.",
    "points": ["uvnitr u vstupu", "pred vstupem", "kriticke misto u sousedu"],
}


def load_config() -> dict:
    if not CONFIG_PATH.exists():
        CONFIG_PATH.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")
        return dict(DEFAULT_CONFIG)
    data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    merged = dict(DEFAULT_CONFIG)
    merged.update(data)
    return merged


def save_config(cfg: dict) -> None:
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def weighting_sos(kind: str, fs: float):
    # IEC 61672 nominal analog weighting curves, bilinear transformed to digital SOS.
    if kind.upper() == "A":
        f1, f2, f3, f4 = 20.598997, 107.65265, 737.86223, 12194.217
        A1000 = 1.9997
        nums = [(2 * math.pi * f4) ** 2 * (10 ** (A1000 / 20)), 0, 0, 0, 0]
        dens = np.polymul([1, 4 * math.pi * f4, (2 * math.pi * f4) ** 2], [1, 4 * math.pi * f1, (2 * math.pi * f1) ** 2])
        dens = np.polymul(np.polymul(dens, [1, 2 * math.pi * f3]), [1, 2 * math.pi * f2])
    elif kind.upper() == "C":
        f1, f4 = 20.598997, 12194.217
        C1000 = 0.0619
        nums = [(2 * math.pi * f4) ** 2 * (10 ** (C1000 / 20)), 0, 0]
        dens = np.polymul([1, 4 * math.pi * f4, (2 * math.pi * f4) ** 2], [1, 4 * math.pi * f1, (2 * math.pi * f1) ** 2])
    else:
        raise ValueError("weighting must be A or C")
    b, a = signal.bilinear(nums, dens, fs)
    return signal.tf2sos(b, a)


def db_from_ms(ms: float, offset: float) -> float:
    return 10.0 * math.log10(max(ms, 1e-20)) + offset


@dataclass
class MetricAccumulator:
    sum_ms_a: float = 0.0
    sum_ms_c: float = 0.0
    n: int = 0
    lafmax: float = -200.0
    lcpeak: float = -200.0

    def add(self, ms_a: float, ms_c: float, laf: float, lcpeak: float):
        self.sum_ms_a += ms_a
        self.sum_ms_c += ms_c
        self.n += 1
        self.lafmax = max(self.lafmax, laf)
        self.lcpeak = max(self.lcpeak, lcpeak)

    def result(self, offset: float) -> dict:
        if self.n == 0:
            return {"LAeq": None, "LCeq": None, "LAFmax": None, "LCpeak": None}
        return {
            "LAeq": db_from_ms(self.sum_ms_a / self.n, offset),
            "LCeq": db_from_ms(self.sum_ms_c / self.n, offset),
            "LAFmax": self.lafmax,
            "LCpeak": self.lcpeak,
        }


@dataclass
class State:
    latest: dict = field(default_factory=dict)
    running: bool = True
    patrol_active: bool = False
    patrol_started: Optional[datetime] = None
    patrol_rows: list = field(default_factory=list)
    point_capture: Optional[dict] = None
    lock: threading.Lock = field(default_factory=threading.Lock)


def fmt(v) -> str:
    return "--.-" if v is None or not math.isfinite(v) else f"{v:5.1f}"


def write_report(cfg: dict, state: State) -> Optional[Path]:
    if not state.patrol_started or not state.patrol_rows:
        return None
    LOG_DIR.mkdir(exist_ok=True)
    stamp = state.patrol_started.strftime("%Y%m%d_%H%M%S")
    html_path = LOG_DIR / f"kontrola_hluku_{stamp}.html"
    csv_path = LOG_DIR / f"kontrola_hluku_{stamp}.csv"

    with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["time", "point", "seconds", "LAeq", "LCeq", "LAFmax", "LCpeak"])
        w.writeheader()
        w.writerows(state.patrol_rows)

    rows_html = "\n".join(
        f"<tr><td>{r['time']}</td><td>{r['point']}</td><td>{r['seconds']}</td>"
        f"<td>{r['LAeq']:.1f}</td><td>{r['LCeq']:.1f}</td><td>{r['LAFmax']:.1f}</td><td>{r['LCpeak']:.1f}</td></tr>"
        for r in state.patrol_rows
    )
    end = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    html = f"""<!doctype html><html lang='cs'><head><meta charset='utf-8'><title>Záznam vlastní kontroly hluku</title>
<style>body{{font-family:Arial,sans-serif;max-width:900px;margin:36px auto;padding:0 20px;color:#111}}h1{{margin-bottom:4px}}.note{{padding:12px;border:2px solid #333;background:#f3f3f3}}table{{border-collapse:collapse;width:100%;margin-top:20px}}th,td{{border:1px solid #aaa;padding:8px;text-align:left}}th{{background:#eee}}.small{{font-size:12px;color:#444}}@media print{{button{{display:none}}body{{margin:0}}}}</style></head><body>
<h1>Záznam vlastní provozní kontroly hluku</h1><p><strong>Provozovna:</strong> {cfg['venue_name']}<br><strong>Zahájeno:</strong> {state.patrol_started.strftime('%d.%m.%Y %H:%M:%S')}<br><strong>Ukončeno:</strong> {end}</p>
<p class='note'><strong>Upozornění:</strong> {cfg['measurement_note']}</p>
<table><thead><tr><th>Čas</th><th>Kontrolní bod</th><th>s</th><th>LAeq dB</th><th>LCeq dB</th><th>LAFmax dB</th><th>LCpeak dB</th></tr></thead><tbody>{rows_html}</tbody></table>
<p class='small'>Měřicí řetězec: mikrofon připojený k PC, digitální A/C vážení, kalibrační offset {cfg['calibration_offset_db']:.2f} dB. Výsledky slouží pro interní provozní kontrolu a nejsou protokolem autorizovaného měření.</p>
<button onclick='window.print()'>Vytisknout / uložit jako PDF</button></body></html>"""
    html_path.write_text(html, encoding="utf-8")
    return html_path


def audio_worker(cfg: dict, state: State):
    fs = int(cfg["sample_rate"])
    blocksize = max(128, int(fs * float(cfg["block_ms"]) / 1000.0))
    offset = float(cfg["calibration_offset_db"])
    sos_a = weighting_sos("A", fs)
    sos_c = weighting_sos("C", fs)
    zi_a = signal.sosfilt_zi(sos_a) * 0
    zi_c = signal.sosfilt_zi(sos_c) * 0

    one_sec = MetricAccumulator()
    one_sec_started = time.monotonic()
    LOG_DIR.mkdir(exist_ok=True)
    live_csv = LOG_DIR / f"live_{datetime.now().strftime('%Y%m%d')}.csv"
    new_file = not live_csv.exists()
    live_f = live_csv.open("a", newline="", encoding="utf-8-sig")
    live_w = csv.writer(live_f)
    if new_file:
        live_w.writerow(["timestamp", "LAeq_1s", "LCeq_1s", "LAFmax_1s", "LCpeak_1s"])

    def callback(indata, frames, time_info, status):
        nonlocal zi_a, zi_c, one_sec, one_sec_started
        if status:
            pass
        x = np.asarray(indata[:, 0], dtype=np.float64)
        ya, zi_a = signal.sosfilt(sos_a, x, zi=zi_a)
        yc, zi_c = signal.sosfilt(sos_c, x, zi=zi_c)
        ms_a = float(np.mean(np.square(ya)))
        ms_c = float(np.mean(np.square(yc)))
        la = db_from_ms(ms_a, offset)
        lc = db_from_ms(ms_c, offset)
        lcpeak = 20.0 * math.log10(max(float(np.max(np.abs(yc))), 1e-10)) + offset
        one_sec.add(ms_a, ms_c, la, lcpeak)

        with state.lock:
            state.latest = {"LA": la, "LC": lc, "LCpeak": lcpeak}
            capture = state.point_capture
            if capture:
                capture["acc"].add(ms_a, ms_c, la, lcpeak)
                if time.monotonic() >= capture["until"]:
                    result = capture["acc"].result(offset)
                    row = {
                        "time": datetime.now().strftime("%H:%M:%S"),
                        "point": capture["point"],
                        "seconds": int(cfg["point_seconds"]),
                        **{k: round(v, 1) for k, v in result.items()},
                    }
                    state.patrol_rows.append(row)
                    state.point_capture = None

        if time.monotonic() - one_sec_started >= 1.0:
            r = one_sec.result(offset)
            live_w.writerow([datetime.now().isoformat(timespec="seconds"), *(round(r[k], 1) for k in ["LAeq", "LCeq", "LAFmax", "LCpeak"])])
            live_f.flush()
            one_sec = MetricAccumulator()
            one_sec_started = time.monotonic()

    try:
        with sd.InputStream(device=cfg.get("input_device"), channels=1, samplerate=fs, blocksize=blocksize, callback=callback):
            while state.running:
                time.sleep(0.1)
    finally:
        live_f.close()


def list_devices():
    print(sd.query_devices())


def calibrate(cfg: dict, target_db: float, seconds: int = 5):
    fs = int(cfg["sample_rate"])
    print(f"Kalibrace: přiveď {target_db:.1f} dB kalibrátor na mikrofon. Měřím {seconds} s...")
    audio = sd.rec(int(seconds * fs), samplerate=fs, channels=1, dtype="float64", device=cfg.get("input_device"))
    sd.wait()
    rms = float(np.sqrt(np.mean(np.square(audio[:, 0]))))
    if rms <= 1e-9:
        raise RuntimeError("Vstup je příliš nízký nebo mikrofon nefunguje.")
    cfg["calibration_offset_db"] = target_db - 20.0 * math.log10(rms)
    save_config(cfg)
    print(f"Hotovo. calibration_offset_db = {cfg['calibration_offset_db']:.3f} dB")


def console_loop(cfg: dict, state: State):
    points = list(cfg.get("points") or [])
    point_index = 0
    print("\nS = začít/ukončit kontrolní obchůzku | M = změřit bod | Q = konec")
    print("Každý bod se měří automaticky po nastavenou dobu.\n")

    if os.name == "nt":
        import msvcrt
    else:
        msvcrt = None

    last_line = ""
    while state.running:
        with state.lock:
            latest = dict(state.latest)
            capture = state.point_capture.copy() if state.point_capture else None
            patrol = state.patrol_active
        warn = ""
        if latest.get("LA", -999) >= float(cfg["warning_laeq_db"]):
            warn += "  !A"
        if latest.get("LC", -999) >= float(cfg["warning_lceq_db"]):
            warn += "  !C/BASY"
        cap = f" | MĚŘÍM: {capture['point']}" if capture else ""
        line = f"LA {fmt(latest.get('LA'))} dB | LC {fmt(latest.get('LC'))} dB | LCpeak {fmt(latest.get('LCpeak'))} dB | {'OBCHŮZKA' if patrol else 'MONITOR'}{cap}{warn}"
        if line != last_line:
            print("\r" + line.ljust(140), end="", flush=True)
            last_line = line

        key = None
        if msvcrt and msvcrt.kbhit():
            key = msvcrt.getwch().lower()
        elif not msvcrt:
            time.sleep(0.2)
        if key == "q":
            state.running = False
        elif key == "s":
            with state.lock:
                if not state.patrol_active:
                    state.patrol_active = True
                    state.patrol_started = datetime.now()
                    state.patrol_rows = []
                    print("\nObchůzka zahájena.")
                else:
                    state.patrol_active = False
                    path = write_report(cfg, state)
                    print(f"\nObchůzka ukončena. Report: {path}")
                    if path:
                        webbrowser.open(path.as_uri())
        elif key == "m":
            with state.lock:
                if not state.patrol_active:
                    print("\nNejdřív stiskni S a zahaj obchůzku.")
                elif state.point_capture:
                    print("\nBod se právě měří.")
                elif not points:
                    print("\nV configu nejsou žádné kontrolní body.")
                else:
                    point = points[point_index % len(points)]
                    point_index += 1
                    state.point_capture = {
                        "point": point,
                        "until": time.monotonic() + int(cfg["point_seconds"]),
                        "acc": MetricAccumulator(),
                    }
                    print(f"\nMěřím bod: {point}")
        time.sleep(0.05)


def main():
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--list-devices", action="store_true")
    parser.add_argument("--calibrate", type=float, metavar="DB_SPL", help="Kalibrace úrovně, typicky 94")
    args = parser.parse_args()
    cfg = load_config()
    if args.list_devices:
        list_devices()
        return
    if args.calibrate is not None:
        calibrate(cfg, args.calibrate)
        return
    print(APP_NAME)
    print(f"Konfigurace: {CONFIG_PATH}")
    print("UPOZORNĚNÍ: interní orientační kontrola, nikoli autorizované měření.")
    state = State()
    t = threading.Thread(target=audio_worker, args=(cfg, state), daemon=True)
    t.start()
    try:
        console_loop(cfg, state)
    except KeyboardInterrupt:
        state.running = False
    t.join(timeout=2)


if __name__ == "__main__":
    main()
