PUB JUKEBOX - NOISE GUARD / Windows 7

1) Nainstaluj Python 3.8.10 (posledni rada vhodna pro Windows 7).
2) Spust INSTALL_WIN7.bat.
3) Pripoj merici mikrofon k PC.
4) Pro seznam vstupu: py -3.8 noise_guard.py --list-devices
5) V noise_guard.json nastav input_device podle cisla zarizeni.
6) Pred prvnim pouzitim udelej kalibraci. S akustickym kalibratorem 94 dB:
   py -3.8 noise_guard.py --calibrate 94
7) Spust START_NOISE_GUARD.bat.

Ovladani:
S = zahajit / ukoncit kontrolni obchuzku
M = zmerit dalsi kontrolni bod
Q = konec

Reporty a prubezne logy jsou ve slozce noise_logs.
Report je INTERNI ORIENTACNI KONTROLA, nikoli autorizovane mereni hluku.

Doporuceni: pro opakovatelna mereni pouzij merici mikrofon s kalibracnim souborem a akusticky kalibrator. Samotny notebookovy/bezny USB mikrofon neni vhodny pro tvrzeni o splneni urednich limitu.
